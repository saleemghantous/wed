import React from 'react'

const LandingPage = () => {
  return (
    <div>
      
    </div>
  )
}

export default LandingPage
