import React from 'react'

const HeaderComp = ({}) => {
  return (
    <div>
      header
    </div>
  )
}

export default HeaderComp
