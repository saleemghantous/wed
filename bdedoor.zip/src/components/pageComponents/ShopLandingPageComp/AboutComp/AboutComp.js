import React from 'react'

const AboutComp = ({}) => {
  return (
    <div>
      About
    </div>
  )
}

export default AboutComp
